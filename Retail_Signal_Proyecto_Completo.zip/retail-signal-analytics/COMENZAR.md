# Empieza por aquí — RETAIL / SIGNAL

1. Abre `powerbi/OnlineRetail.pbip` desde esta carpeta nueva. Actualizar un informe anterior no incorpora automáticamente este rediseño.
2. Si aparece la conversión a TMDL, elige **No actualizar**; no es necesaria.
3. Pulsa **Inicio → Actualizar** para cargar los CSV. Si moviste la carpeta, ajusta DataFolder siguiendo `powerbi/LEEME.md`.
4. Recorre las cuatro páginas. En modo de edición de Desktop, activa los botones laterales con **Ctrl + clic**, o usa las pestañas inferiores.
5. En `Dashboard_Ventas.xlsx`, empieza en **Resumen** y cambia mes/país en **Filtros**, D5 y D6. Productos, Clientes y Países cubren el periodo completo.
6. Lee `Informe_Ejecutivo.pdf` y practica con `report/Guion_Portafolio.md`.

La entrega anterior se conserva por separado. Las vistas de Excel y PDF se revisaron; la carga, DAX, interacciones y apariencia nativa de Power BI requieren comprobarse en Desktop.

Para GitHub, lee `PUBLICAR_EN_GITHUB.md`. No se ha publicado ningún archivo.
