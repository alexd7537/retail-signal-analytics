# Diccionario de datos

## Archivo original

Cada fila corresponde a una línea de documento. La hoja contiene ocho campos:

| Campo | Tipo analítico | Unidad / significado |
|---|---|---|
| InvoiceNo | Texto | Documento; C indica cancelación/abono según la fuente |
| StockCode | Texto | Código de producto o de movimiento especial, recortado y convertido a mayúsculas en todas las tablas |
| StockCodeOriginal | Texto | Código de origen antes de recortar y convertir a mayúsculas; solo en transactions_audited.csv |
| Description | Texto | Descripción original del producto o ajuste |
| Quantity | Entero | Unidades con signo |
| InvoiceDate | Fecha y hora | Momento de registro, sin zona horaria especificada |
| UnitPrice | Decimal | GBP por unidad, hasta tres decimales |
| CustomerID | Texto nullable | Identificador; no es una variable numérica |
| Country | Texto | País del cliente |

## Campos añadidos en transactions_audited.csv

| Campo | Tipo | Regla |
|---|---|---|
| SourceRow | Entero | Fila original de Excel: 2 es la primera fila de datos |
| Date | Fecha ISO | Fecha sin hora |
| YearMonth | Texto YYYY-MM | Periodo cronológico |
| Hour | Entero 0-23 | Hora del documento |
| Weekday | Entero 0-6 | 0=lunes, 6=domingo |
| RecordClass | Categoría | Producto, Envio, Ajuste o Vale |
| TransactionType | Categoría | Venta, Abono o Revision |
| AmountGBP | Decimal | Quantity × UnitPrice, con signo |
| AmountMilliGBP | Entero | Importe en milésimas de GBP; control exacto |
| DuplicateCandidate | 0/1 | 1 si existe una fila idéntica anterior en las ocho columnas originales |
| MissingDescription | 0/1 | Descripción originalmente vacía |
| KnownCustomer | 0/1 | 1 si existe CustomerID |
| Included | 0/1 | Producto y transacción Venta/Abono elegible |

Se conserva `CustomerID=UNKNOWN` para faltantes y `Description=SIN DESCRIPCIÓN` cuando corresponde. El archivo original conserva el valor vacío, mientras que la extracción lo normaliza.

## Modelo estrella

- **FactTransactions:** una fila por línea comercial elegible. Clave técnica SourceRow.
- **DimProduct:** StockCode único también sin distinguir mayúsculas y descripción más frecuente; desempate alfabético. Las variantes como 84997B / 84997b se agregan bajo 84997B, conservando todas sus transacciones.
- **DimCustomer:** CustomerID único, incluido UNKNOWN.
- **DimCountry:** Country único.
- **DimDate:** Date único y continuo; YearMonth, Year, Month, Weekday (1=lunes, 7=domingo), CompleteMonth (0 para diciembre 2011).
- **Quality:** resumen por RecordClass y TransactionType de toda la fuente, desconectado del modelo comercial.

La diferencia de codificación de Weekday es explícita: la extracción auditada usa 0-6, la dimensión del modelo usa 1-7. No deben unirse por ese campo. La relación de tiempo utiliza Date.

## Agregados

`monthly.csv`, `countries.csv` y `cube.csv` contienen GrossGBP, CreditGBP, NetGBP, Orders, CreditDocuments, Customers, RepeatCustomers, Units, CreditUnits, KnownGrossGBP y Rows. `cube.csv` incluye totales denominados Todos: **no se suman las filas del cubo**, se selecciona una combinación mes/país. Los conteos distintos se calculan directamente en cada población.

`products.csv` agrega por StockCode. `customers.csv` agrega solo clientes identificados y agrega LastPurchase y Segment. Un cliente con abonos pero sin compras tiene Orders=0, LastPurchase vacío y Segment=Solo abonos. No se divide su bruto por cero.

`reconciliation.csv` incluye RecordClass, TransactionType, Rows, AmountGBP e Included. Las filas son grupos mutuamente excluyentes y pueden sumarse para recuperar el total firmado original. Los indicadores generales de calidad se solapan y no deben sumarse entre sí.
