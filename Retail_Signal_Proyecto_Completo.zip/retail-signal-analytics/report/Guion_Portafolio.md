# Cómo presentar y defender este proyecto

## Presentación de 2-3 minutos

**0:00-0:25 — Problema.** «Este es un caso de portafolio con datos públicos de una tienda online. El problema era convertir más de medio millón de líneas en una visión clara de ventas, productos, clientes y abonos.»

**0:25-0:55 — Trabajo realizado.** «Preparé un proceso reproducible, conservé el archivo original y añadí trazabilidad por fila. Separé productos de portes y ajustes. No eliminé clientes desconocidos de las ventas y documenté los posibles duplicados.»

**0:55-1:30 — Dashboard.** Abre Resumen y muestra £9,79 millones netos, 19.773 pedidos y £519,47 de ticket bruto. Cambia Filtros a noviembre 2011 y Germany, vuelve a Resumen y explica cómo cambian las tarjetas. Después vuelve a Todos/Todos.

**1:30-2:05 — Hallazgo relevante.** Abre Validación. «Dos ventas grandes tienen abonos equivalentes del mismo día y explican 51,3% del importe abonado. Antes de recomendar una campaña para reducir devoluciones, revisaría esas operaciones con administración.»

**2:05-2:35 — Acciones y valor.** «También detecté concentración geográfica y ventas sin cliente identificado. Propuse revisar los motivos de abono, mejorar la captura del cliente y estudiar disponibilidad de los productos principales.»

**2:35-2:50 — Cierre.** «El entregable incluye dashboard, modelo de datos, SQL, metodología y un informe ejecutivo. El mismo flujo se puede adaptar a una exportación comercial de un cliente.»

No se incluye una grabación: el guion está pensado para que la presentes con tu propia voz. Antes de publicar, debes poder explicar cada decisión y ejecutar una parte del análisis por tu cuenta. Si te preguntan por las herramientas, indica que usaste asistencia de IA en el desarrollo y distingue lo que ya dominas.

## Texto para publicar en tu portafolio

**Online Retail: ventas, clientes y calidad de datos**

Caso empresarial simulado con 541.909 líneas transaccionales públicas. Preparé una extracción auditada, definí métricas comerciales y diseñé vistas de ventas, productos, clientes y abonos. El análisis identifica £9,79 millones en ventas netas de productos y muestra por qué dos operaciones extremas cambian la interpretación de los abonos. Incluye Excel, SQL, modelo Power BI editable, código reproducible e informe ejecutivo. Desarrollado con asistencia de IA y con decisiones de limpieza documentadas.

No escribas «incrementé las ventas», «reduje devoluciones» ni «ahorré dinero a mi cliente»: esas mejoras no se implementaron ni midieron.

## Preguntas que debes poder responder

1. **¿Qué representa cada fila?** Una línea de documento, no un pedido.
2. **¿Por qué no eliminaste filas sin cliente?** Son ventas válidas para los importes, aunque no sirven para contar clientes identificados.
3. **¿Por qué el neto no coincide con la suma de toda la fuente?** Se separaron envío, ajustes, vales y registros en revisión. Existe un puente que concilia el total.
4. **¿Por qué no llamas a los abonos “devoluciones” en todos los casos?** No hay causa ni clave de enlace al documento de venta original.
5. **¿Por qué conservaste duplicados?** La igualdad exacta sugiere duplicación, pero puede representar líneas legítimas. Se entrega sensibilidad y se pediría confirmación al dueño del sistema.
6. **¿Qué tiene de malo sumar clientes mensuales?** El mismo cliente aparece en varios meses. Hay que recalcular distintos en la población seleccionada.
7. **¿Por qué diciembre cae?** El último diciembre solo contiene nueve días; no se puede comparar con noviembre completo.
8. **¿Dónde está la utilidad?** No puede calcularse sin costos. Ventas netas no equivale a beneficio.
9. **¿Qué falta para automatizarlo con un cliente real?** Acordar las reglas, parametrizar su origen, probar nuevas extracciones, implementar y validar actualización en el entorno del cliente.
10. **¿Qué verificaste?** Totales en Python/SQLite, claves, conciliación exacta, filtros y fórmulas de Excel. El refresco y renderizado nativo de Power BI están pendientes.

## Servicio que este caso respalda

«Organizo sus datos de ventas y construyo un reporte con indicadores, evolución, productos, clientes y abonos, acompañado de validaciones y recomendaciones.»

Para un primer encargo, acota: una fuente, un formato estable, un periodo, indicadores acordados, una versión del dashboard y una ronda de revisión. Pregunta por moneda, impuestos, descuentos, costos, devoluciones, identificadores y frecuencia de actualización antes de cotizar.
