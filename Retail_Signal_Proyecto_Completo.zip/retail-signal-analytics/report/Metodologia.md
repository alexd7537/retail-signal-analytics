# Metodología y decisiones de limpieza

## Pregunta empresarial y alcance

Evaluar ventas, productos, clientes, mercados y abonos de Online Retail. El indicador principal es **venta neta de productos**, no ingreso contable total ni beneficio. El periodo observado es 01/12/2010 08:26 a 09/12/2011 12:50. Los importes están en GBP.

La unidad de observación es una **línea de documento**, no un pedido. `InvoiceNo` se repite legítimamente cuando hay varios productos. `StockCode` es la clave del producto; una descripción puede cambiar y no debe convertirse en clave.

## Capas de información

1. El XLSX original permanece intacto en la ubicación indicada por el usuario.
2. `transactions_audited.csv` contiene todas las filas, con el número de fila de Excel `SourceRow`, clasificación y banderas de calidad.
3. `FactTransactions.csv` contiene solo líneas comerciales elegibles de productos.
4. Las dimensiones tienen claves únicas; todos los valores de la tabla de hechos encuentran su dimensión.
5. Los agregados calculan cada métrica desde la población correspondiente. Los totales de clientes no se obtienen sumando clientes mensuales.

## Reglas, en orden

| Regla | Implementación | Motivo |
|---|---|---|
| Identificadores | InvoiceNo, StockCode, CustomerID y Country se tratan como texto | No sumar ni redondear claves |
| Cliente vacío | `UNKNOWN` | Mantener ventas, excluir del conteo de compradores |
| Descripción vacía | `SIN DESCRIPCIÓN`, con bandera del valor original | No inventar el nombre del producto |
| Espacios | Recorte exterior y normalización de espacios de descripción | Consistencia de etiquetas |
| Clave de producto | StockCode se recorta y convierte a mayúsculas antes de construir hechos, dimensiones y agregados; StockCodeOriginal conserva el texto fuente en la auditoría | Evitar colisiones como 84997B / 84997b en Power BI, que no distingue mayúsculas; no se eliminan líneas de venta |
| Envío | POST, DOT, C2 | Conciliar por separado |
| Ajustes | M, D, S, BANK CHARGES, AMAZONFEE, CRUK, B; comparación sin distinguir mayúsculas | Manuales, descuentos, muestras, comisiones y ajustes no son ventas de producto |
| Vales | Códigos que comienzan con GIFT_ | No confundir vales con productos físicos |
| Producto | Cualquier otro código | Incluye códigos especiales DCGS/PADS; no se exige un patrón exclusivamente numérico |
| Venta elegible | Precio > 0, cantidad > 0, documento numérico | Línea positiva de venta |
| Abono elegible | Precio > 0, cantidad < 0, documento comienza por C | Valor negativo vinculado a cancelación/abono según el diccionario |
| Revisión | Cualquier otra combinación | Se excluye del KPI comercial y se conserva para conciliación |
| Alcance principal | Clase Producto + Venta o Abono elegible | Población consistente para ventas de productos |

`RecordClass=Ajuste` puede contener descuentos comerciales legítimos. El proyecto los presenta fuera de la venta de productos por no existir una clave para asignarlos a una línea/pedido original. Por tanto, la métrica no pretende representar ingreso contable reconocido ni neto final de toda la factura.

## Duplicados y extremos

Se detectan 5.268 repeticiones posteriores exactamente iguales en las ocho columnas originales. **Se conservan**, ya que el archivo no contiene un identificador de línea que permita demostrar que son duplicados de carga. La alternativa elimina solo la segunda y siguientes repeticiones, nunca todas las líneas de una factura. En la población de productos, 5.257 líneas son repeticiones candidatas. El neto principal es £9.792.708,883 y la alternativa £9.771.318,163. Diferencia: £21.390,720.

No se eliminan automáticamente cantidades o importes extremos. Las ventas 541431 y 581483 tienen abonos C541433 y C581484 con igual producto, cliente, fecha e importe absoluto. Los dos pares suman £245.653,20 en cada sentido. Esto sugiere una corrección o cancelación, pero no demuestra la causa. No se cambia el bruto ni se asignan devoluciones artificialmente. No se interpreta abonos/bruto como una tasa causal de devolución de pedidos.

## Definiciones de indicadores

| Indicador | Numerador / definición | Denominador / población |
|---|---|---|
| Bruto | Suma de importes de Venta | Productos elegibles |
| Abonos | Valor positivo de los importes de Abono | Productos elegibles |
| Neto | Bruto - Abonos | Fecha de registro de cada documento |
| Pedidos | Facturas distintas con al menos una línea Venta | Selección actual |
| Ticket bruto | Bruto | Pedidos |
| Abonos / bruto | Valor abonado | Bruto de la misma selección; no cohortes |
| Clientes compradores | Clientes identificados distintos con Venta | Excluye UNKNOWN y clientes con solo abonos |
| Clientes recurrentes | Compradores con >= 2 facturas positivas distintas | Ventana analizada, no retención futura |
| Recurrencia | Clientes recurrentes | Clientes compradores |
| Cobertura de cliente | Bruto con cliente identificado | Bruto total de productos |
| Unidades | Suma positiva de Quantity | Venta, sin restar abonos |
| Concentración top 10 productos | Neto de 10 productos líderes | Neto total de productos |
| Concentración top 10 clientes | Neto de 10 clientes líderes | Neto de todos los clientes identificados, incluidos clientes con solo abonos |
| Variación mensual | Neto actual / neto anterior - 1 | Solo meses completos y base anterior positiva |

La suma de pedidos por producto puede superar los pedidos del negocio: una factura puede contener varios productos. El mismo principio aplica a clientes por mes. Las relaciones del modelo son muchos a uno y filtran de dimensión a hecho. No se unen los resúmenes de clientes a las líneas para evitar multiplicaciones.

## Fechas, moneda y precisión

Se conservan fechas y horas sin inventar zona horaria. Diciembre de 2011 es parcial. No se anualizan esos nueve días y la variación MoM de ese mes se marca no aplicable. Un ciclo anual permite describir demanda, no demostrar estacionalidad repetida.

Los precios tienen hasta tres decimales. El procesamiento convierte el precio a milésimas de GBP y multiplica por unidades enteras. Así, las conciliaciones de importes son exactas; el reporte solo redondea la presentación a dos decimales.

## Validación y reproducción

`analysis/validation.json` contiene los controles ejecutados. Incluyen filas originales, partición incluido/excluido, importe firmado, resultados independientes en SQLite, unicidad de productos sin distinguir mayúsculas y facturas dentro de un solo mes/país. `src/verify.py` comprueba además todas las dimensiones sin distinguir mayúsculas, sus relaciones con las transacciones y los pedidos distintos por producto después de normalizar. El SHA-256 del archivo está en `analysis/results.json`.

El libro de Excel se validó con el motor de artefactos, incluyendo filtros Alemania/noviembre 2011, total general y revisión visual. Power BI recibió verificaciones estructurales de campos, relaciones y posición de visuales. La ejecución de Power Query, DAX y el refresco nativo en Desktop está pendiente. No confundir esas comprobaciones con una captura nativa de Power BI.

## Diferencias respecto de la guía inicial

La guía inicial proponía eliminar duplicados y restar todo registro que no fuera Venta. Se corrigió esa simplificación: una fila en revisión o un ajuste positivo no se debe contar automáticamente como devolución. También se evita calcular una tasa de pedidos cancelados sin vínculo entre factura y abono. Se mantuvieron las filas sin CustomerID para no infravalorar ventas.

## Fuente

Chen, D. (2015), Online Retail. UCI, https://doi.org/10.24432/C5BW33. CC BY 4.0. Modificaciones y límites descritos arriba.
