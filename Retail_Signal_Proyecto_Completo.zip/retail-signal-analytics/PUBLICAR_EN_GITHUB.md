# Publicación y mantenimiento del portafolio

Repositorio: [alexd7537/retail-signal-analytics](https://github.com/alexd7537/retail-signal-analytics).

Estado de Power BI: pendiente de comprobar las cuatro páginas dentro de Power BI Desktop, incluidos filtros, navegación y totales. La revisión de estructura no sustituye esta prueba nativa.

La entrega local incluye CSV y SQLite. La copia para GitHub mantiene código, modelo, reporte, Excel, PDF, portada y documentación, pero excluye datos completos, cachés y archivos temporales. La ruta local se sustituye por un parámetro de ejemplo.

```bash
python src/prepare_github.py
```

El script crea una carpeta hermana `github_retail_signal`. No altera la entrega local ni publica nada. Si ya existe, usa `--output` con un nombre nuevo.

Nombre del repositorio: **retail-signal-analytics**.

Descripción: Análisis comercial de Online Retail con Python, SQL, Power BI y Excel: ventas, clientes, productos y calidad de datos.

Temas sugeridos: data-analysis, power-bi, python, sql, excel, data-cleaning, portfolio.

## Antes de subir

1. Revisar Power BI y obtener capturas nativas. No presentar la portada o las vistas del Excel como capturas de Power BI.
2. Ejecutar `python -m unittest discover -s tests -v` en la copia ligera.
3. Revisar el primer commit: no incluir .pbi, cache.abf, credenciales ni archivos personales.
4. Conservar la atribución a UCI y diferenciar hallazgos, hipótesis y acciones propuestas.
5. Elegir la licencia para el código. CC BY 4.0 corresponde a los datos; no se ha elegido automáticamente una licencia para tu código.

Para Upwork, enlaza la página principal del repositorio. Comprueba que las imágenes se lean bien y conserva la distinción entre capturas de Excel, portada editorial y futuras capturas nativas de Power BI. No agregues información de contacto a los archivos destinados al portafolio de Upwork.
