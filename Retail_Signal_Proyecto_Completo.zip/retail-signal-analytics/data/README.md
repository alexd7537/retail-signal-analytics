# Fuente de datos

Online Retail, Chen (2015), UCI. https://doi.org/10.24432/C5BW33. Licencia: CC BY 4.0.

La copia de GitHub excluye los datos completos. Descarga el XLSX desde UCI y ejecuta `src/analyze.py --input "RUTA/Online Retail.xlsx"`.

`processed/` es una salida regenerable. `raw/` permite guardar la descarga local y está ignorada por Git. No subir datos privados de futuros clientes.
