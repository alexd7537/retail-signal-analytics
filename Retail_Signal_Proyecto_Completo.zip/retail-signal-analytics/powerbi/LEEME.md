# RETAIL / SIGNAL en Power BI

Cuatro páginas con navegación lateral, filtros desplegables, tarjetas, gráficos y tablas nativos. El tema ya está integrado.

## Abrir la nueva versión

1. Guarda cualquier trabajo pendiente y abre este `OnlineRetail.pbip`, no el informe anterior.
2. Si Desktop propone convertir a TMDL, selecciona **No actualizar**. El modelo entregado usa TMSL.
3. Pulsa **Inicio → Actualizar**. Deben cargarse 536.465 líneas comerciales.
4. Sin filtros, compara: neto £9.792.708,883; pedidos 19.773; ticket £519,47. La tarjeta del neto resume en millones y las tablas conservan el detalle.
5. Prueba los filtros y la navegación. En modo de edición de Desktop usa **Ctrl + clic** en los botones laterales; también puedes usar las pestañas inferiores.

## Si se movió la carpeta

En **Transformar datos → Administrar parámetros**, cambia `DataFolder` a la ruta absoluta de `data/processed`. Alternativamente, con Power BI cerrado:

```bash
python src/configure_data.py --folder "RUTA/retail-signal/data/processed"
```

Este script solo cambia la ruta; conserva visuales y medidas. `build_powerbi.py` regenera modelo y diseño, por lo que no debe ejecutarse sobre personalizaciones sin respaldo.

## Las cuatro vistas

- **Panorama:** evolución comercial y cinco mercados líderes de la selección.
- **Productos:** diez códigos líderes, principales abonos y detalle con descripción.
- **Clientes:** compradores, recurrencia y cobertura. UNKNOWN no cuenta como comprador identificado.
- **Calidad:** conciliación global sin filtros comerciales.

Top N se calcula sobre la selección; los empates pueden producir más de N elementos. Diciembre 2011 incluye solo días 1–9. Las repeticiones exactas se conservan en la métrica principal.

## Verificación

Se comprobaron estructura PBIR, campos, relaciones, navegación, lienzo, tema y esquemas oficiales. **No se ejecutó la carga ni se verificó el renderizado nativo de Power BI Desktop.** No se entrega un PBIX validado.

[Temas de Power BI](https://learn.microsoft.com/en-us/power-bi/create-reports/desktop-report-themes) · [Formato PBIR](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report)
