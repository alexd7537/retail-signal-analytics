"""Pruebas estructurales sin motor nativo Power BI ni datos completos."""
from pathlib import Path
import json,unittest
ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'powerbi/OnlineRetail.Report'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
class ReportTests(unittest.TestCase):
    def setUp(self):
        self.model=read(ROOT/'powerbi/OnlineRetail.SemanticModel/model.bim')['model']
        self.visuals=[read(p) for p in (REPORT/'definition/pages').glob('*/visuals/*/visual.json')]
    def test_star_model(self):
        self.assertEqual(len(self.model['tables']),6)
        self.assertEqual(len(self.model['relationships']),4)
        for rel in self.model['relationships']:
            self.assertEqual(rel['toCardinality'],'one');self.assertEqual(rel['fromCardinality'],'many')
    def test_fields_exist(self):
        known={t['name']:{c['name'] for c in t['columns']}|{m['name'] for m in t.get('measures',[])} for t in self.model['tables']}
        for v in self.visuals:
            for role in v['visual'].get('query',{}).get('queryState',{}).values():
                for item in role['projections']:
                    f=next(iter(item['field'].values()))
                    self.assertIn(f['Property'],known[f['Expression']['SourceRef']['Entity']])
    def test_layout_bounds(self):
        for v in self.visuals:
            p=v['position'];self.assertGreaterEqual(p['x'],0);self.assertGreaterEqual(p['y'],0)
            self.assertLessEqual(p['x']+p['width'],1440);self.assertLessEqual(p['y']+p['height'],900)
    def test_navigation(self):
        pages=read(REPORT/'definition/pages/pages.json')['pageOrder'];self.assertEqual(len(pages),4)
        buttons=[v for v in self.visuals if v['visual']['visualType']=='actionButton']
        self.assertEqual(len(buttons),16)
        for button in buttons:
            props=button['visual']['visualContainerObjects']['visualLink'][0]['properties']
            self.assertIn(props['navigationSection']['expr']['Literal']['Value'].strip("'"),pages)
    def test_theme_registered(self):
        meta=read(REPORT/'definition/report.json');theme=meta['themeCollection']['customTheme']['name']
        self.assertTrue((REPORT/'StaticResources/RegisteredResources'/theme).is_file())
        self.assertEqual(read(REPORT/'StaticResources/RegisteredResources'/theme)['name'],theme)
    def test_unique_visual_names(self):
        self.assertEqual(len(self.visuals),len({v['name'] for v in self.visuals}))
    def test_no_cached_hyperlink_errors(self):
        self.assertNotIn('HYPERLINK(', (ROOT/'src/build_workbook.mjs').read_text(encoding='utf-8'))
if __name__=='__main__':unittest.main()
